function takeaction(recordId){
    $(".selectedrowId").val(recordId);

    var csrfName = $('.txt_csrfname').attr('name'); // Value specified in $config['csrf_token_name']
    var csrfHash = $('.txt_csrfname').val(); // CSRF hash

    $.ajax({
        url: '../../professor/Enrolments/showRequests',
        type: 'POST',
        data: {recordId:recordId, [csrfName]: csrfHash},
        error: function() {
            
        },
        success: function(data) {  
            var obj = jQuery.parseJSON(data);
            $('.txt_csrfname').val(obj.token);
            $(".modal-body").html(obj.modal_html);
            $('#examAction').modal('show');
        }
     }); 
}

function submitApproval(approvalType){
    var recordId = $(".selectedrowId").val();
    var csrfName = $('.txt_csrfname').attr('name'); // Value specified in $config['csrf_token_name']
    var csrfHash = $('.txt_csrfname').val(); // CSRF hash
    
    $.ajax({
        url: '../../professor/Enrolments/submitApproval',
        type: 'POST',
        data: {recordId:recordId, approvalType:approvalType, [csrfName]: csrfHash},
        error: function() {
            
        },
        success: function(data) {  
            var obj = jQuery.parseJSON(data);
            $('.txt_csrfname').val(obj.token);
            if(obj.result_status == '1'){
                if(approvalType == '1'){
                    $(".actionButton").html("<p class='textToDisplay'>Request Approved</p>");
                    $(".actionRow"+recordId).html('<span class="label label-success">Request Approved</span></br />Professor : You </br> Date: '+obj.approvalTime);
                }
                else{
                    $(".actionButton").html("<p class='textToDisplay'>Request Declined</p>");
                    $(".actionRow"+recordId).html('<span class="label label-danger">Request Declined</span><br />Professor : You <br /> Date: '+obj.approvalTime);
                }
            }
            else{
                $(".actionButton").html("<p class='textToDisplay'>Update Unsuccessfull. Please try again later.</p>");
            }
           
            
        }
     });
}

