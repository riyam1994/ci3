<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php
class MY_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
		error_reporting(E_ALL ^ E_NOTICE);
		/*$this->load->model("common_settings_model");
		$this->common_settings = $this->common_settings_model->getSettings();*/
		date_default_timezone_set('America/Edmonton');
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");
		 
		 
    }
     
	 public function check_student_login($page='')
    { 
        if($page=='login')
		{  
			if(isset($this->session->userdata['logged_sId'.base_url()]) && isset($this->session->userdata['logged_sName'.base_url()]))
			{
				redirect(base_url().'dashboard', 'location');
				//exit(0);
			}
		}
		else
		{   
			if($this->session->userdata['logged_sId'.base_url()] == "" || $this->session->userdata['logged_sName'.base_url()] == "")
			{
				//$this->clear_session();
				redirect(base_url().'login', 'location');
				//exit(0);
			}
		}
    }
    
	public function check_professor_login($page='')
    { 
        if($page=='login')
		{  
			if(isset($this->session->userdata['logged_pId'.base_url()]) && isset($this->session->userdata['logged_pName'.base_url()]))
			{
				redirect(base_url().'professor/dashboard', 'location');
				//exit(0);
			}
		}
		else
		{   
			if($this->session->userdata['logged_pId'.base_url()] == "" || $this->session->userdata['logged_pName'.base_url()] == "")
			{
				//$this->clear_session();
				redirect(base_url().'professor/login', 'location');
				//exit(0);
			}
		}
    }
    
	
	

	/*public function clear_session_logout()
	{
		
		$this->session->set_userdata('logged_fuId'.base_url(), '');
		$this->session->set_userdata('logged_fuName'.base_url(), '');
		$this->session->set_userdata('logged_fuType'.base_url(), '');
	}*/
	
	

	
}
?>