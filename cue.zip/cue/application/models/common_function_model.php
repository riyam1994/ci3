<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_function_model extends CI_model{
	
	public function loginvalidate($table,$field,$where)	// function for validating password form
	{
		
		$this->db->select($field);		
		$this->db->from($table);
		$this->db->where($where);

		$this->query = $this->db->get(); // executing query
		$this->result = $this->query->result_array();	// getting result
		
		return $this->result; // returns result

	}	// function loginvalidate ends

	public function join_three_tables($fields, $table1, $table2, $table3, $onCondition1, $onCondition2, $where, $joinType1, $joinType2, $orderBy,$groupBy)
	{
		
		$this->db->select($fields);
		$this->db->from($table1);
		$this->db->join($table2, $onCondition1, $joinType1);
		if($table3 != NULL)
		{
			$this->db->join($table3, $onCondition2, $joinType2);
		}
		if($where != NULL)
		{
			$this->db->where($where);
		}
		if($orderBy != NULL)
		{
			$this->db->order_by($orderBy);
		}
		if($groupBy != NULL)
		{
			$this->db->group_by($groupBy);
		}
		
		$query 	 = $this->db->get();
		$result  = $query->result_array();
		return $result;
	}
	public function insert_record($table,$insertItems)
	{
		$result = $this->db->insert($table, $insertItems);
		
		return $result;
	}

		
}
?>
