<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_function_model extends CI_model{
	
	public function loginvalidate($table,$field,$where)	// function for validating password form
	{
		
		$this->db->select($field);		
		$this->db->from($table);
		$this->db->where($where);

		$this->query = $this->db->get(); // executing query
		$this->result = $this->query->result_array();	// getting result
		
		return $this->result; // returns result

	}	// function loginvalidate ends

	public function join_three_tables($fields, $table1, $table2, $table3, $onCondition1, $onCondition2, $where, $joinType1, $joinType2, $orderBy,$groupBy)
	{
		
		$this->db->select($fields);
		$this->db->from($table1);
		$this->db->join($table2, $onCondition1, $joinType1);
		if($table3 != NULL)
		{
			$this->db->join($table3, $onCondition2, $joinType2);
		}
		if($where != NULL)
		{
			$this->db->where($where);
		}
		if($orderBy != NULL)
		{
			$this->db->order_by($orderBy);
		}
		if($groupBy != NULL)
		{
			$this->db->group_by($groupBy);
		}
		
		$query 	 = $this->db->get();
		$result  = $query->result_array();
		return $result;
	}

	public function join_five_tables($fields, $table1, $table2, $table3, $table4, $table5, $onCondition1, $onCondition2, $onCondition3, $onCondition4, $where, $joinType1, $joinType2, $joinType3, $joinType4, $orderBy,$groupBy)
	{		
		$this->db->select($fields);
		$this->db->from($table1);
		$this->db->join($table2, $onCondition1, $joinType1);
		if($table3 != NULL)
		{
			$this->db->join($table3, $onCondition2, $joinType2);
		}
		if($table4 != NULL)
		{
			$this->db->join($table4, $onCondition3, $joinType3);
		}
		if($table5 != NULL)
		{
			$this->db->join($table5, $onCondition4, $joinType4);
		}
		
		if($where != NULL)
		{
			$this->db->where($where);
		}
		if($orderBy != NULL)
		{
			$this->db->order_by($orderBy);
		}
		if($groupBy != NULL)
		{
			$this->db->group_by($groupBy);
		}
		
		$query 	 = $this->db->get();
		$result  = $query->result_array();
		return $result;
	}

	public function fetch_all_records($table, $fields, $where = NULL, $orderBy = NULL)
	{
		$this->db->select( $fields);
		$this->db->from($table);
		if($where != NULL)
		{
			$this->db->where($where);
		}
		if($orderBy != NULL)
		{
			$this->db->order_by($orderBy);
		}

		$query = $this->db->get();
		$result = $query->result_array();
		return $result;
	}

	public function fetch_single_val($table, $field, $where)
	{
		 
		$this->db->select($field);
		$this->db->from($table);
		$this->db->where($where);

		$query 	= $this->db->get();
		$result = $query->result();
		if(empty($result[0]))
		{
			return "";
		}
		else
		{
		return $result[0]->$field;
		}
	}
	
	public function update_record($table,$updateItems,$condition)
	{
		$this->db->where($condition);
		$this->db->update($table, $updateItems);
		return TRUE;
	}
	
}
?>
