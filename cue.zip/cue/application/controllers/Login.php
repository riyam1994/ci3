<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 30-Jan-2022
Last changed on : 30-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Login extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->pageTitle = 'Login | Dev Task';
		$this->load->helper('url');
		$this->load->library('session');
		$this->check_student_login('login');
	}	// __construct ends
	
	public function index()
	{
		$this->load->model("common_function_model"); // get general functions associated with database
		$this->load->view("include/header");
		//$this->load->view("include/head");			
	
		 if($this->input->get_post('signup_now')!='')	// is sign in form with username and password entered
		{
			$this->getintoDashboard();
		}
		else
		{
			$this->load->view("login_view");
		}
		//$this->load->view("include/footer");	
		
	}	
	
	
	
	public function getintoDashboard()	// function to check the validity of a student by checking userid, password 
	{
		/* Load form helper */ 
		$this->load->helper(array('form'));
			
		/* Load form validation library */ 
		$this->load->library('form_validation');
		$this->load->helper('security');
		   
		/* Set validation rule for name field in the form */ 
   
		$this->form_validation->set_rules('userid', 'User ID', 'trim|required|xss_clean',);
		$this->form_validation->set_rules('userpassword', 'Password', 'trim|required|xss_clean');
		
		if($this->form_validation->run() == FALSE)	// if the username is null or password is null.
		{
			//$data['errorMessage']="Please enter a valid username and password";
			$this->load->view("login_view");
		}
		else
		{
			
			$userid = $this->input->post('userid');	
			$userpassword = $this->input->post('userpassword');	
			$userpassword = md5($userpassword);
			
			$this->load->model("common_function_model");	// load the functions for login page from login_model
			$where = "student_email = '$userid' and student_password = '$userpassword' and status = '1'";
			$this->result = $this->common_function_model->loginvalidate("tbl_students","*",$where); // if success, function returns the id, username and usertype
				
			if($this->result)  // setting the sessions 
			{ 	
			
				$this->session->set_userdata('logged_sId'.base_url(), $this->result[0]['id']); // user id as session
				$this->session->set_userdata('logged_sName'.base_url(), $this->result[0]['student_name']); // name of the user
						
				redirect(base_url().'dashboard', 'refresh');
			}
			else
			{ 
				$data['rightUserflag']=1; // setting the flag to pass to login page as entered username is available in database
				$data['errorMessage']="Invalid credentials";
				$this->load->view("login_view",$data);
			}
		}
		
	}	// function getintoDashboard ends

}	// class Login ends
?>