<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 30-Jan-2022
Last changed on : 30-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Pagenotfound extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->pageTitle = '404 | Dev Task';
		$this->load->helper('url');
	}	// __construct ends
	
	public function index()
	{
		
		$this->load->view("include/header");			
		$this->load->view("pagenotfound_view");
		//$this->load->view("include/footer");	
		
	}	
	

}	// class Login ends
?>