<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 30-Jan-2022
Last changed on : 30-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Dashboard extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->pageTitle = 'Dashboard | Dev Task';
		//$this->load->helper('url');
		$this->load->library('session');
		$this->check_student_login();
	}	// __construct ends
	
	public function index()
	{
		$this->load->model("common_function_model"); // get general functions associated with database
		$this->load->view("include/header");	
		$this->load->view("include/head");		
	
		$this->load->view("dashboard_view");
		
		$this->load->view("include/footer");	
		
	}	
	
	

}	// class Login ends
?>