<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logout extends MY_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->pageType = 'logout';
		$this->check_professor_login();
	}
	public function index()
	{
	    
	    //$this->session->unset_userdata('some_name');
		$this->session->unset_userdata('logged_pId'.base_url());
		$this->session->unset_userdata('logged_pName'.base_url());
		/*$this->session->set_userdata('logged_pId'.base_url(), '');
		$this->session->set_userdata('logged_pName'.base_url(), '');
		$this->session->sess_destroy();*/
    	 
		redirect(base_url()."professor/login", 'refresh');
		
	}

	
}
?>