<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 30-Jan-2022
Last changed on : 30-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Dashboard extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->pageTitle = 'Dashboard | Dev Task';
		//$this->load->helper('url');
		$this->load->library('session');
		$this->check_professor_login();
	}	// __construct ends
	
	public function index()
	{
		$this->load->model("professor/common_function_model"); // get general functions associated with database
		$this->load->view("professor/include/header");	
		$this->load->view("professor/include/head");		
	
		$data['allCourses'] = $this->common_function_model->fetch_all_records('tbl_courses','*',NULL,"course_name ASC");
		$this->load->view("professor/dashboard_view",$data);
		
		$this->load->view("professor/include/footer");	
		
	}	
	
	

}	// class Login ends
?>