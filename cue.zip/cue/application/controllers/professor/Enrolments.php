<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 31-Jan-2022
Last changed on : 31-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Enrolments extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct(); 
		$this->pageTitle = 'Enrolments | Dev Task';
		$this->load->library('session');
		$this->check_professor_login();
	}	// __construct ends
	
	public function listEnrolments($courseId)
	{ 
		$this->load->model("professor/common_function_model"); // get general functions associated with database
		$this->load->view("professor/include/header");	
		$this->load->view("professor/include/head");		
	
		
		//$data['allEnrolments'] = $this->common_function_model->join_three_tables('tbl_courses.course_name,tbl_exam_requests.*,tbl_students.student_name','tbl_courses', 'tbl_exam_requests', 'tbl_students',"tbl_courses.id = tbl_exam_requests.course_id", "tbl_students.id = tbl_exam_requests.student_id","tbl_exam_requests.course_id = '$courseId'", $joinType1 = 'left', $joinType2 = 'left', $orderBy = 'tbl_exam_requests.request_time asc',NULL);

		$data['allEnrolments'] = $this->common_function_model->join_five_tables('tbl_courses.course_name,tbl_exam_requests.*,tbl_students.student_name,tbl_professors.professor_name,tbl_professors.id as profId', 'tbl_courses', 'tbl_exam_requests', 'tbl_students', 'tbl_professors',NULL, "tbl_courses.id = tbl_exam_requests.course_id", "tbl_students.id = tbl_exam_requests.student_id", 'tbl_exam_requests.professor_id = tbl_professors.id', NULL,"tbl_exam_requests.course_id = '$courseId'", $joinType1 = 'left', $joinType2 = 'left', $joinType3 = 'left', $joinType4 = 'left', 'tbl_exam_requests.request_time asc',$groupBy = NULL);
		
		$data['courseName'] = $this->common_function_model->fetch_single_val('tbl_courses','course_name',"id = '$courseId'");
		$this->load->view("professor/enrolments_view",$data);
		
		$this->load->view("professor/include/footer");	
		
	}	
	
	public function showRequests(){
		$recordId = $this->input->get_post('recordId');

		$this->load->model("professor/common_function_model");
		$enrolmentDetail = $this->common_function_model->join_three_tables('tbl_courses.course_name,tbl_exam_requests.*,tbl_students.student_name','tbl_courses', 'tbl_exam_requests', 'tbl_students',"tbl_courses.id = tbl_exam_requests.course_id", "tbl_students.id = tbl_exam_requests.student_id","tbl_exam_requests.id = '$recordId'", $joinType1 = 'left', $joinType2 = 'left', $orderBy = NULL,NULL);

		$html = "";
		foreach($enrolmentDetail as $enrolment){
			$html .= '<input type="hidden" class="selectedrowId" value="'.$recordId.'" />
            <p>Exam Name: '.$enrolment['course_name'].'</p>
            <p>Student Name: '.$enrolment['student_name'].'</p>
			<p>Applied On: '.date('d-m-Y h:i:s a', strtotime($enrolment['request_time'])).'</p>
			<p>Requested Date: '.date('d-m-Y h:i:s a', strtotime($enrolment['exam_date'])).'</p>
            <p>Student Comment: '.$enrolment['student_comment'].'</p>
           
            
            <hr>
				<span class="actionButton">
					<button type="button" class="btn btn-primary" onclick="submitApproval(1);">APPROVE</button>
					<button type="button" class="btn btn-danger" onclick="submitApproval(2);">DECLINE</button>
				</span>';
		}
		$data['modal_html'] = $html;
		$data['token'] = $this->security->get_csrf_hash();
		echo json_encode($data);

	}

	public function submitApproval()
	{
		$recordId = $this->input->get_post('recordId');
		$approvalType = $this->input->get_post('approvalType');

		$professorId = $this->session->userdata['logged_pId'.base_url()];
		$approvalTime =  date("Y-m-d H:i:s");	

		$this->load->model("professor/common_function_model");
		$updatearray= array(
			'approval_status' => $approvalType,
			'approved_time' => $approvalTime,
			'professor_id' => $professorId
		  );
		$condition = "id = ".$recordId;
		$updateStatus 	 = $this->common_function_model->update_record('tbl_exam_requests',$updatearray, $condition);
		$data = array();
		if($updateStatus){
			$data['result_status'] = 1;
		}
		
		$data['approvalTime'] = date('F jS, Y  h:i:s a', strtotime($approvalTime));
		
		$data['token'] = $this->security->get_csrf_hash();
		echo json_encode($data);

	}
	
	

}	// class Enrolments ends
?>