<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
Author: Riya Baby
Created on		: 30-Jan-2022
Last changed on : 30-Jan-2022
Last changed by : Riya Baby
About: student login
*/
class Courses extends MY_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->pageTitle = 'Courses | Dev Task';
		//$this->load->helper('url');
		$this->load->library('session');
		$this->check_student_login();
	}	// __construct ends
	
	public function index()
	{
		$this->load->model("common_function_model"); // get general functions associated with database
		$this->load->view("include/header");	
		$this->load->view("include/head");		
	
		
		$student_id = $this->session->userdata['logged_sId'.base_url()];;
		$data['allCourses'] = $this->common_function_model->join_three_tables('tbl_courses.*,tbl_exam_requests.request_time,tbl_exam_requests.approval_status,tbl_exam_requests.exam_date,tbl_exam_requests.approved_time,tbl_professors.professor_name','tbl_courses', 'tbl_exam_requests', 'tbl_professors',"tbl_courses.id = tbl_exam_requests.course_id and tbl_exam_requests.student_id = '$student_id'", "tbl_professors.id=tbl_exam_requests.professor_id","tbl_courses.status = '1'", $joinType1 = 'left', $joinType2 = 'left', $orderBy = 'tbl_courses.course_name asc',NULL);
					
		//print_r($data);die;
		$this->load->view("courses_view",$data);
		
		$this->load->view("include/footer");	
		
	}	
	
	
	
	public function requestForExam()	// function to check the validity of a student by checking userid, password 
	{
		
		$courseId = $this->input->get_post('courseId');
		$studentComments = $this->input->get_post('studentComments');
		$examdaytime = $this->input->get_post('examdaytime');
		
		$examdaytime = date('Y-m-d h:i:s', strtotime($examdaytime));
		
		$studentId = $this->session->userdata['logged_sId'.base_url()];
		$requestTime =  date("Y-m-d H:i:s");

		$this->load->model("common_function_model"); // get general functions associated with database
		
		$insertItems 	 = array(
									'course_id ' => $courseId,
									'student_id' => $studentId,
									'exam_date' => $examdaytime,
									'student_comment' => $studentComments,
									'request_time' => $requestTime,
									'approval_status' => '0',
									'approved_time' => NULL,
									'professor_id' => NULL
								);
					
		$insertStatus 	 = $this->common_function_model->insert_record('tbl_exam_requests',$insertItems);
		
		$data = array();
		if($insertStatus){
			$data['result_status'] = 1;
		}
		
		$data['requestTime'] = date('F jS, Y h:i:s a', strtotime($requestTime));
		$data['applyTime'] = date('F jS, Y h:i:s a', strtotime($examdaytime));
		
		$data['token'] = $this->security->get_csrf_hash();
		echo json_encode($data);
		
	}	// function requestForExam ends

}	// class Courses ends
?>