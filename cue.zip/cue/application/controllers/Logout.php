<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logout extends MY_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->pageType = 'logout';
		$this->check_student_login();
	}
	public function index()
	{
	    
	    $this->session->unset_userdata('logged_sId'.base_url());
		$this->session->unset_userdata('logged_sName'.base_url());
		/*$this->session->set_userdata('logged_sId'.base_url(), '');
		$this->session->set_userdata('logged_sName'.base_url(), '');
		$this->session->sess_destroy();*/
    	 
		redirect(base_url()."login", 'refresh');
		
	}

	
}
?>