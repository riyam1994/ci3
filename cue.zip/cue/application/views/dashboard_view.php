<div class="container-fluid">
    <div class="row pagerow">
        <div class="col-sm-12">
          <h2><u>Dashboard</u></h2>
        </div>
        <div class="col-sm-12">
          <p>Click on the button below to view available Courses and request for an Examnination:</p>
          <a href="<?php echo base_url(); ?>courses" class="btn btn-primary" >View Courses</a>
        </div>
    </div>
</div>