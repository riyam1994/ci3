
<div class="container-fluid">
    <div class="row pagerow">
        <div class="col-sm-12">
          <h2><u>Courses</u></h2>
        </div>
        <div class="col-sm-12">
        
          <table id="courseTable">
            <tr>
              <th>Number</th>
              <th>Course</th>
              <th>Exam Date Applied</th>
              <th>Action</th>
            </tr>
            <?php
              if(count($allCourses) > 0){
                $i = 0;
                foreach($allCourses as $courses)
                {
                  $i++;
                ?>
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><span class="courseName<?php echo $courses['id']; ?>"><?php echo $courses['course_name']; ?></span></td>
                  <td><span class="applyBox<?php echo $courses['id']; ?>">
                    <?php 
                    if($courses['exam_date'] != ''){
                      echo date('F jS, Y h:i:s a', strtotime($courses['exam_date']));
                    }
                    else{
                      echo '-';
                    }
                    ?>
                    </span>
                  </td>
                  <td>
                    <?php
                    if($courses['request_time'] == ''){
                      echo '<span class="requestBox'.$courses['id'].'"><button class="btn btn-primary" onclick="sendrequest('.$courses['id'].');">Request</button>';
                    }
                    else{
                      if($courses['approval_status'] == '0'){
                        $requestTime = date('F jS, Y h:i:s a', strtotime($courses['request_time']));
                        echo '<span class="label label-warning">Request Pending (Applied on '.$requestTime.')</span>';
                      }
                      else if($courses['approval_status'] == '1'){
                        $approved_time = date('F jS, Y h:i:s a', strtotime($courses['approved_time']));
                        echo '<span class="label label-success">Request Approved</span><br>Professor : '.$courses['professor_name'].'<br>Time: '.$approved_time;
                      }
                      else{
                        $approved_time = date('F jS, Y h:i:s a', strtotime($courses['approved_time']));
                        echo '<span class="label label-danger">Request Declined </span><br>Professor : '.$courses['professor_name'].'<br />Time :'.$approved_time;
                      }
                    }
                    ?>
                  </td>
                </tr>
                <?php
                }
              }
              else{
            ?>
            <tr>
              <td colspan="4">Sorry, No Courses to list!</td>
            </tr>
            <?php
              }
              ?>
          </table>
          
        </div>
        <div class="col-sm-12">
        <a href="<?php echo base_url(); ?>dashboard" class="btn btn-primary" >Go to Home</a>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="examReg" role="dialog">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"></h4>
          </div>
          <div class="modal-body">
            <input type="hidden" class="selectedCourseId" />
            <input type="hidden" class="txt_csrfname" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
            <div class="screen1">
              <p>Please select a date and time and click on 'NEXT'</p>
              <div class="examdateValidation"></div>
              
                <?php 
                //$today = date("Y-m-d").'T'.date("h:i"); 
                //date('Y-m-d', strtotime('+1 day', strtotime($date)))
                 $tomorrow = date('Y-m-d', strtotime('+1 day', strtotime(date("Y-m-d")))).'T'.date("h:i");
                ?>
              <input type="datetime-local" id="examdaytime"  min="<?php echo $tomorrow; ?>"  required/>
              
            </div>
            <div class="screen2" style="display:none;">
              <span class="textToDisplay"></span>
              <br />
              <div>Enter your Comment:<span class="commentValidation">*</span></div>
              <textarea rows="4" cols="70" class="studentComment"></textarea>
            </div>
            <div class="screen3" style="display:none;">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary nextBtn" onclick="showScreen2();">NEXT</button>
            <button type="button" class="btn btn-default closeBtn" style="display:none;" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-warning backBtn" style="display:none;" onclick="showScreen1();">BACK</button>
            <button type="button" class="btn btn-primary submitBtn" style="display:none;" onclick="submitRequest();">SUBMIT</button>
          </div>
        </div>
      </div>
    </div>
</div>
