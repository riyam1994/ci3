
<div class="container-fluid">
    <div class="row pagerow">
        <div class="col-sm-12">
          <h2><u>Enrolments for <?php echo $courseName; ?></u></h2>
        </div>
        <div class="col-sm-12">
        
          <table id="courseTable">
            <tr>
              <th>Number</th>
              <th>Student</th>
              <th>Student Comment</th>
              <th>Applied On</th>
              <th>Requested Exam Date</th>
              <th>Action</th>
            </tr>
            <?php
              if(count($allEnrolments) > 0){
                $i = 0;
                foreach($allEnrolments as $enrolments)
                {
                  $i++;
                ?>
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $enrolments['student_name']; ?></td>
                  <td>
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#viewComment<?php echo $enrolments['id']; ?>">Read Comment</button>
                      <!-- Student Comment Modal -->
                      <div class="modal fade" id="viewComment<?php echo $enrolments['id']; ?>" role="dialog">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Student Comment</h4>
                            </div>
                            <div class="modal-body">
                            <?php echo $enrolments['student_comment']; ?>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                        </div>
                      </div>
                  </td>
                  <td>
                    <?php 
                    $requestTime = date('F jS, Y h:i:s a', strtotime($enrolments['request_time']));
                    echo $requestTime;
                    ?>
                  </td>
                  <td>
                    <?php echo date('F jS, Y h:i:s a', strtotime($enrolments['exam_date'])); ?>
                  </td>
                  <td><span class="actionRow<?php echo $enrolments['id']; ?>">
                    <?php
                     if($enrolments['approval_status'] == '0'){
                        
                      echo '<button class="btn btn-warning" onclick="takeaction('.$enrolments['id'].');" >Approve/Decline</button>';
                    }
                    else if($enrolments['approval_status'] == '1'){
                      $approved_time = date('F jS, Y h:i:s a', strtotime($enrolments['approved_time']));
                      echo '<span class="label label-success">Request Approved</span><br /> Professor :';
                      if($enrolments['profId'] == $this->session->userdata['logged_pId'.base_url()]){
                          echo "You";
                      }
                      else{
                        echo $enrolments['professor_name'];
                      }
                      echo ' <br />Date - '.$approved_time;
                    }
                    else{
                      $approved_time = date('F jS, Y h:i:s a', strtotime($enrolments['approved_time']));
                      echo '<span class="label label-danger">Request Declined</span> <br />Professor :';
                      if($enrolments['profId'] == $this->session->userdata['logged_pId'.base_url()]){
                        echo "You";
                      }
                      else{
                        echo $enrolments['professor_name'];
                      }
                      echo ' <br /> Date: '.$approved_time;
                    }

                    ?></span>
                  </td>
                </tr>
                <?php
                }
              }
              else{
            ?>
            <tr>
              <td colspan="6">Sorry, No Enrolments!</td>
            </tr>
            <?php
              }
              ?>
          </table>
          <input type="hidden" class="txt_csrfname" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
          
        </div>
        <div class="col-sm-12">
        <a href="<?php echo base_url(); ?>professor/dashboard" class="btn btn-primary" >Back</a>
        </div>
    </div>
    <!-- Exam approve/decline Modal -->
    <div class="modal fade" id="examAction" role="dialog">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Approve/Decline Exam Request</h4>
          </div>
          <div class="modal-body">
            
          </div>
          <div class="modal-footer">
            
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary submitBtn" style="display:none;" onclick="submitRequest();">SUBMIT</button>
          </div>
        </div>
      </div>
    </div>

    
</div>
