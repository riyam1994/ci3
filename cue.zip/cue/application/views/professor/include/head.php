<div class="container-fluid">
    <div class="row headerrow">
        <div class="col-sm-8">
          Hello <?php echo $this->session->userdata['logged_pName'.base_url()]; ?> !
        </div>
        <div class="col-sm-4">
          <a class="logoutBtn" href="<?php echo base_url(); ?>professor/logout">Logout <i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </div>
    </div>
</div>