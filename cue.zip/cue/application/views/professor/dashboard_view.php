<div class="container-fluid">
    <div class="row pagerow">
        <div class="col-sm-12">
          <h2><u>Courses</u></h2>
        </div>
        <div class="col-sm-12">
        <table id="courseTable">
            <tr>
              <th>Number</th>
              <th>Course</th>
              <th>Action</th>
            </tr>
            <?php
              if(count($allCourses) > 0){
                $i = 0;
                foreach($allCourses as $courses)
                {
                  $i++;
                ?>
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $courses['course_name']; ?></td>
                  <td>
                    <?php 
                    if($courses['status'] != '0'){
                      echo '<a class="btn btn-primary" href="'.base_url().'professor/enrolments/'.$courses['id'].'">View Enrolments</a>';
                    }
                    else{
                      echo '<span class="label label-danger">Deactivated</span>';
                    }
                    ?>
                  </td>
                  
                </tr>
                <?php
                }
              }
              else{
            ?>
            <tr>
              <td colspan="3">Sorry, No Courses to list!</td>
            </tr>
            <?php
              }
              ?>
          </table>
        </div>
    </div>
</div>