
    <div class="container container_row">
      <div class="wrapper">
        <div class="title"><span>Login | Student Portal</span></div>
        <form action="" method="post">
        <?php
            if(isset($rightUserflag)){
                ?>
                <span style='color:red;'><?php echo $errorMessage; ?></span>
                <?php
            }
        ?> 
         <?php echo validation_errors(); ?>  
         <?php echo form_open('form'); 
         $csrf = array(
          'name' => $this->security->get_csrf_token_name(),
          'hash' => $this->security->get_csrf_hash()
          );
          ?> 
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="email" name="userid" placeholder="User ID" required>
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" name="userpassword" placeholder="Password" required>
            <!--<input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" /> -->
          </div>
          
          <div class="row button">
            <!-- <button class="btn btn-info" name="signup_now" value="1" type="submit">Log In</button> -->
            <input type="submit" value="Login"name="signup_now" />
          </div>
          
        </form>
      </div>
    </div>

    </body>
</html>
